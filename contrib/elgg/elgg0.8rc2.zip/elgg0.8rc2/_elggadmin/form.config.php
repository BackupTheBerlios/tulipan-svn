<?php

    foreach(get_object_vars($PARSEDCFG) as $name => $value) {
        
        echo "<p>" . $name . ":</p>";
        
    }

?>