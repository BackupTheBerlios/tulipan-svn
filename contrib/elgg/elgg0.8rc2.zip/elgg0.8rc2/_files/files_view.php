<?php

    /*
    *    View files
    */

    // Get current folder    
    
        global $folder;
        if (!isset($folder)) {
            echo "!!!";
        }
    
?>