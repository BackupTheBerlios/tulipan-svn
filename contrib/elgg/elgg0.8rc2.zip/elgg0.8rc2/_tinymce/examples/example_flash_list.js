// This list may be created by a server logic page PHP/ASP/ASPX/JSP in some backend system.
// There flash movies will be displayed as a dropdown in all flash dialogs if the "flash_external_list_url"
// option is defined in TinyMCE init.

var tinyMCEFlashList = new Array(
	// Name, URL
	["Some Flash 1", "test1.swf"],
	["Some Flash 2", "test2.swf"]
);
