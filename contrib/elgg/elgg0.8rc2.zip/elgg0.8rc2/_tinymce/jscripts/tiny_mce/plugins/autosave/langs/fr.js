// FR lang variables
// Modified by Motte, last updated 2006-03-23

tinyMCE.addToLang('',{
autosave_unload_msg : 'Vos modifications seront perdues si vous quittez cette page.'
});
