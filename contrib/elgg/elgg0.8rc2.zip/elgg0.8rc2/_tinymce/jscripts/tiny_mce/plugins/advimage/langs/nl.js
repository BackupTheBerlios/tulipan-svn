// NL lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Algemeen',
tab_appearance : 'Beeld',
tab_advanced : 'Geavanceerd',
general : 'Algemeen',
title : 'Titel',
preview : 'Voorbeeld',
constrain_proportions : 'Verhoudingen behouden',
langdir : 'Taalrichting',
langcode : 'Taalcode',
long_desc : 'Link naar lange omschrijving',
style : 'Stijl',
classes : 'Stijlen',
ltr : 'Links naar rechts',
rtl : 'Rechts naar links',
id : 'Id',
image_map : 'Afbeelding opdelen',
swap_image : 'Afbeelding wisselen',
alt_image : 'Alternatieve afbeelding',
mouseover : 'voor muis-over',
mouseout : 'voor muis-uit',
misc : 'Diversen',
example_img : 'Voorbeeld&nbsp;afbeelding',
missing_alt : 'Zonder een beschrijving van de afbeelding, zal de pagina voor mensen met een visuele handicap of met afbeeldingen uitgeschakeld niet toegankelijk zijn. Weet u zeker dat u wilt doorgaan zonder beschrijving?'
});
