// Simplified Chinese lang variables contributed by TinyMCE_China_Team ( tinymce_china {AT} yahoogroups {DOT} com ).
// visit our homepage at: http://www.cube316.net/tinymce/ for more information.

/* Remember to namespace the language parameters <your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : '这是一个模板弹出窗口',
template_desc : '这是一个模板按钮'
});
