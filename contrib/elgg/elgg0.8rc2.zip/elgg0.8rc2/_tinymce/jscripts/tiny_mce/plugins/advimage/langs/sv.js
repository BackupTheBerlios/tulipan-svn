// SE lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Generella inst�llningar',
tab_appearance : 'Visuella inst�llningar',
tab_advanced : 'Avancerade inst�llningar',
general : 'Generella',
title : 'Titel',
preview : 'F�rhandsgranskning',
constrain_proportions : 'Beh�ll proportionerna',
langdir : 'Skriftriktning',
langcode : 'Spr�kkod',
long_desc : 'L�ng beskrivning',
style : 'Stil',
classes : 'Stilmallsklasser',
ltr : 'V�nster till h�ger',
rtl : 'H�ger till v�nster',
id : 'Id',
image_map : 'Bildkarta',
swap_image : 'Byt bild',
alt_image : 'Alternativ bild',
mouseover : 'n�r pekaren g�r �ver',
mouseout : 'n�r pekaren g�r utanf�r',
misc : '�vrigt',
example_img : 'F�rhandsgranskningsbild',
missing_alt : '�r du s�ker p� att du vill forts�tta utan att skriva en bildbeskrivning. Utan en alternativ beskrivning �r bilden inte handikappanpassad.'
});
