// Simplified Chinese lang variables contributed by TinyMCE_China_Team ( tinymce_china {AT} yahoogroups {DOT} com ).
// visit our homepage at: http://www.cube316.net/tinymce/ for more information.

tinyMCE.addToLang('',{
directionality_ltr_desc : '方向从左往右',
directionality_rtl_desc : '方向从右往左'
});
