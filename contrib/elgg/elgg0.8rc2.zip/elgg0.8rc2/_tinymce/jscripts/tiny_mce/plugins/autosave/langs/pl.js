// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl
// fixed by lemiel 14.11.2005

tinyMCE.addToLang('',{
autosave_unload_msg : 'Zmiany jakie wprowadziłeś zostaną utracone, jeśli opuścisz teraz tę stronę.'
});
