// FR lang variables
// Modified by Motte, last updated 2006-03-23

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Vers la droite',
directionality_rtl_desc : 'Vers la gauche'
});
