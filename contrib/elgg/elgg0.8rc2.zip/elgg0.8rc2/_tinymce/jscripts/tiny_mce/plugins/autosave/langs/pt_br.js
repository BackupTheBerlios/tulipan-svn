/**
 * pt_br lang variables
 * Brazilian Portuguese
 *
 * Author
 * Revision and modifications:
 *           Marcio Barbosa (mpg) <mpg@mpg.com.br>
 * First Release : November 26, 2005 - TinyMCE Version : 2.0RC4
 * Last Updated : November 20, 2006 - TinyMCE Version : 2.0.8
 */
tinyMCE.addToLang('',{
autosave_unload_msg : 'As modifica&ccedil;&otilde;es feitas ser&atilde;o perdidas caso voc&ecirc; navegue fora desta p&aacute;gina.'
});
