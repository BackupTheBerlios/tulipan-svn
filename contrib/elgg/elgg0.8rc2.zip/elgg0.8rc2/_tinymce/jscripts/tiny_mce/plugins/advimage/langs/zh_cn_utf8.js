// Simplified Chinese lang variables contributed by TinyMCE_China_Team ( tinymce_china {AT} yahoogroups {DOT} com ).
// visit our homepage at: http://www.cube316.net/tinymce/ for more information.

tinyMCE.addToLang('advimage',{
tab_general : '一般',
tab_appearance : '显示',
tab_advanced : '高级',
general : '一般',
title : '标题',
preview : '预览',
constrain_proportions : '约束属性',
langdir : '书写方向',
langcode : '语言编码',
long_desc : '长描述链接',
style : '风格',
classes : '类',
ltr : '从左至右',
rtl : '从右至左',
id : '表识',
image_map : '图片对应',
swap_image : '调换图片',
alt_image : '候选图片',
mouseover : '鼠标在上面时',
mouseout : '鼠标离开时',
misc : '杂项',
example_img : '显示&nbsp;预览&nbsp;图片',
missing_alt : '您确认要在没有图片说明的情况下继续吗？ 这样其他关闭图片浏览的用户将无法注意到你在这里有图片。'
});
