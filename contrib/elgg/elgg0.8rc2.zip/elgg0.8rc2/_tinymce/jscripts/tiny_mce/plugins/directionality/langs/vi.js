// Vietnamese lang variables - Đỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Hướng trái sang phải',
directionality_rtl_desc : 'Hướng phải sang trái'
});
