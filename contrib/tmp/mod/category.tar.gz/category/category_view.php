<?php

    // Display posts in this category
    print __gettext("Category view");
?>
