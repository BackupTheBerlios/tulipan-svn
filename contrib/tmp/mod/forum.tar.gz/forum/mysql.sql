alter table prefix_weblog_posts add column last_updated int(11) NOT NULL default '0' COMMENT 'unix timestamp';
